﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NBehave.Examples")]
// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("88f12384-a3eb-417f-ac4a-58a84fece318")]
